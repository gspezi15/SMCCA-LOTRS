local waddleDeeBoss = require("DemoResources/waddledeeboss")

local totalDees = 0
local totalDeeIncreaseTimer = 0
local deesKilled = 0

local dees = {}

local deeTimers = {}

function onStart()
    totalDees = totalDees + 1
    waddleDeeBoss.spawn()
end

function onEvent(eventname)
    if eventname == "WaddleDeeDefeated" then
        deesKilled = deesKilled + 1
        table.insert(dees, waddleDeeBoss.spawn(totalDees >= 13))
        totalDees = totalDees + 1
        if totalDees < 22 * 8 + 1 then
            table.insert(deeTimers, 180)
            if totalDees == 13 then
                for k,v in ipairs(dees) do
                    v.drawHP = waddleDeeBoss.drawBossHP
                end
            end
        end
    end
end

function onDraw()
    Text.printWP(deesKilled, 20, 20, 5)
end

function onTick()
    for i=#deeTimers, 1, -1 do
        deeTimers[i] = deeTimers[i] - 1

        if deeTimers[i] == 0 then
            table.insert(dees, waddleDeeBoss.spawn(totalDees >= 13))
            table.remove(deeTimers, i)
        end
    end
end