local adversary = require("adversary")
local projectiles = require("projectiles")

local w = {}

local bossSprite = Graphics.loadImage(Misc.resolveFile("DemoResources/waddledee.png"))

local waddledeeCount = 0
local dees = {}

-- For projectiles, a list is created and returns onTick and onDraw handlers. See below. CTRL + F to find them.
local deathEffectProjectile = projectiles.createList{
    sprite = "DemoResources/deathEffect.png",
    width = 66,
    height = 46,
    z = 0
}

local deathEffectExplosionProjectile = projectiles.createList{
    sprite = "DemoResources/explosion.png",
    width = 160,
    height = 160,
    z = 0.1
}

-- Map a column in the animation sprite to a constant for easy access
local ANIMSTATE = {
    WALK = 0,
    JUMP = 1,
    JUMPUP = 2,
    FALL = 3,
    HURT = 4,
}

-- Two-dimensional state machine. Makes handling complex attacks easier
local STATE = {
    WALK = 0,
    JUMP = 1,
    HURT = 2
}

local SUBSTATE = {
    DEFAULT = 0,
    SUB1 = 1,
    SUB2 = 2,
    SUB3 = 3,
}

local stateFrameCounts = {
    [0] = 8,
    [1] = 1,
    [2] = 4,
    [3] = 1,
    [4] = 1
}

-- Helper functions for my state machine

local function switchAnimation(b, newstate)
	if newstate == b.frameX then return end
	b.frameTimer = 0
	b.framespeed = 8
    b.frameX = newstate
end

local function switchSubState(b, newstate)
	b.subStateTimer = 0
	b.subState = newstate
end

local function switchBehaviour(b, newstate)
	b.attackTimer = 0
	switchSubState(b, SUBSTATE.DEFAULT)
	b.state = newstate
end

-- This one is just really neat for semi-smart ai behaviour
local function consider(p)
	return RNG.random(0,1) <= p
end

-- Routine functions

local function r_walk(v)
    if v.attackTimer == 1 then
        switchAnimation(v, ANIMSTATE.WALK)
    end

    v.speedX = v.direction

    if v.attackTimer >= 80 then
        if consider(0.1) then
            switchBehaviour(v, STATE.JUMP)
        end
    end
end

local function r_jump(v)
    if v.attackTimer == 1 then
        switchAnimation(v, ANIMSTATE.JUMP)
        v.speedX = 0
    end

    if v.subState == SUBSTATE.DEFAULT then
        if v.subStateTimer >= 30 then
            switchSubState(v, SUBSTATE.SUB1)
            switchAnimation(v, ANIMSTATE.JUMPUP)
            v.speedY = -4
            v.speedX = 1.2 * v.direction
            SFX.play("DemoResources/sfx_aim.wav")
        end
    else
        if v.speedY >= 0 then
            switchAnimation(v, ANIMSTATE.FALL)
        end
        if v.grounded and not v.wasGrounded then
            SFX.play("DemoResources/sfx_squeak.wav")
            switchBehaviour(v, STATE.WALK)
        end
    end
end

local function r_hurt(v)
    if v.attackTimer == 1 then
        v.speedX = 0
        v.speedY = 0
        switchAnimation(v, ANIMSTATE.HURT)
    end

    if v.subState == SUBSTATE.DEFAULT then
        if v.subStateTimer >= 40 then
            switchSubState(v, SUBSTATE.SUB1)
            v.speedX = v.speedX + v.storedSpeed.x
            v.speedY = v.speedY + v.storedSpeed.y
            v.storedSpeed = vector.zero2
        end
    elseif v.subState == SUBSTATE.SUB1 then
        if (v.grounded and not v.wasGrounded) or v.subStateTimer > 200 then
            v.speedX = v.speedX * 0.8
            v.speedY = math.abs(v.speedX) * -1
            SFX.play("DemoResources/sfx_squeak.wav")
            if math.abs(v.speedX) < 2 then
                switchSubState(v, SUBSTATE.SUB2)
            else
                v.subStateTimer = 0
            end
        end
    elseif v.subState == SUBSTATE.SUB2 then
        if (v.grounded and not v.wasGrounded) or v.subStateTimer > 200 then
            v.speedX = 0
            v.speedY = 0
            SFX.play("DemoResources/sfx_squeak.wav")
            switchSubState(v, SUBSTATE.SUB3)
        end
    else
        if v.subStateTimer >= 35 then
            if v.hp <= 0 then
                v.active = false
                v:toggleHP()
                v:remove()
                deathEffectProjectile:spawn{x = v.x, y = v.y, speedX = RNG.random(-4, 4), speedY = RNG.random(-6, -8)}
            else
                switchBehaviour(v, STATE.WALK)
            end
        end
    end
end

local routine = {
    [STATE.WALK] = r_walk,
    [STATE.JUMP] = r_jump,
    [STATE.HURT] = r_hurt,
}

local function onBossTick(v)

    routine[v.state](v)

    v.iFrames = math.max(v.iFrames - 1, 0)
    v.opacity = math.cos((v.iFrames % 4) / 4)
    v.attackTimer = v.attackTimer + 1
    v.subStateTimer = v.subStateTimer + 1
    v.frameTimer = v.frameTimer + 1

    v.x = v.x + v.speedX
    v.speedY = v.speedY + v.gravity
    v.y = v.y + v.speedY

    v.collider.x = v.x
    v.collider.y = v.y

    do -- Collision
        if v.x + v.width > -199240 then
            v.x = -199240 - v.width
            v.speedX = -v.speedX
            v.direction = -v.direction
        end

        if v.x < -199960 then
            v.x = -199960
            v.speedX = -v.speedX
            v.direction = -v.direction
        end

        v.wasGrounded = v.grounded
        v.grounded = false
        if v.y + v.height > -200272 then
            v.grounded = true
            v.speedY = 0
            v.y = -200272 - v.height
        end

        if v.y < -200448 then
            v.y = -200448
            v.speedY = -v.speedY
        end
    end
end

local function onBossDraw(v)
    v.frameY = math.floor(v.frameTimer / v.framespeed) % stateFrameCounts[v.frameX]

    if v.direction == 1 then
        v.frameX = v.frameX + 5
    end
    v:draw()
    if v.direction == 1 then
        v.frameX = v.frameX - 5
    end
end

-- The onHarm function expects you to (modify and) return damage
local function onBossHarm(v, source, damage, culprit)
    if damage < 0 or v.iFrames > 0 then return 0 end

    if culprit ~= nil then
        if culprit.__type == "NPC" then
            culprit:kill(3)
        end

        if source == adversary.HARM_JUMP or source == adversary.HARM_DOWNSLASH then
            Colliders.bounceResponse(culprit)
        end

        v.storedSpeed.x = v.storedSpeed.x + damage * culprit.direction + culprit.speedX * 0.2
        v.storedSpeed.y = v.storedSpeed.y - damage
    else
        v.storedSpeed.x = v.storedSpeed.x + damage * -v.direction
        v.storedSpeed.y = v.storedSpeed.y - damage
    end

    switchBehaviour(v, STATE.HURT)
    if v.subState ~= SUBSTATE.DEFAULT then
        switchSubState(v, SUBSTATE.DEFAULT)
    end
    v.iFrames = 30
    v.subStateTimer = v.subStateTimer - 15
    SFX.play("DemoResources/sfx_smallmeteor.wav")

    if v.hp > 0 and v.hp - damage <= 0 then
        triggerEvent("WaddleDeeDefeated") -- propagate notification of death upwawrds
        SFX.play("DemoResources/sfx_playerhurt.wav")
    end
    return damage
end

local hpImage = Graphics.loadImage(Misc.resolveFile("DemoResources/hp.png"))

function w.drawBossHP(boss, number)
    if boss.hp <= 0 then
        boss:toggleHP()
        return
    end
	local offsetX = number
	local y = adversary.bossHPCoords.y
	local w = 34
	local x = adversary.bossHPCoords.x - (w) * (offsetX - 1)
	while x <= w do
		x = x + math.ceil((adversary.bossHPCoords.x - w)/ w) * w
		y = y - 34
    end
    
    Graphics.drawImageWP(hpImage, x - 32, y, 5)
    Graphics.drawBox{
        priority = 4.99,
        x = x - 30,
        width = 28,
        y = y + 32 - 32 * (boss.hp / boss.maxHP),
        height = 32 * (boss.hp / boss.maxHP),
        color = Color.blue
    }
end

function w.spawn(shortHPDraw)
    waddledeeCount = waddledeeCount + 1
    local boss = adversary.createBoss(
        bossSprite,
        {
            x = RNG.random(-199960, -199300),
            y = -200448,
            width = 60,
            height = 56,
            gfxwidth = 60,
            gfxheight = 56,
            gfxoffsety = 2,
            direction = RNG.irandomEntry{-1, 1},
            frameX = 0,
            frameY = 0,
            hp = 10,
            name = "Waddle Dee " .. waddledeeCount,

            -- custom values
            grounded = false,
            wasGrounded = false,
            frameTimer = 0,
            framespeed = 8,
            storedSpeed = vector(0,0),
            gravity = 0.1,

            -- You can also define timers here
            attackTimer = 0,
            subState = 0,
            subStateTimer = 0,
            frameTimer = 0
        }
    )
    -- Set the boss active to set onTick, onDraw and the harm handling active
    boss.active = true

    if shortHPDraw then
        boss.drawHP = w.drawBossHP
    end

    -- What can hit the boss?
    boss:registerHarmSource(adversary.HARM_JUMP, 1)
    boss:registerHarmSource(adversary.HARM_SLASH, 1.5)
    boss:registerHarmSource(adversary.HARM_DOWNSLASH, 1.5)
    boss:registerHarmSource(adversary.HARM_TAIL, 0.75)
    boss:registerHarmSource(adversary.HARM_TONGUE, 3)
    boss:registerHarmSource(adversary.HARM_FIREBALL, 0.5)
    boss:registerHarmSource(adversary.HARM_HAMMER, 0.75)
    boss:registerHarmSource(adversary.HARM_ICEBALL, 0.5)
    boss:registerHarmSource(adversary.HARM_LASER, 0.75)

    -- Damage multipliers for state
    boss:registerStateHarm({
        [STATE.WALK] = 1,
        [STATE.JUMP] = 1,
        [STATE.HURT] = 0.3,
    })

    -- Custom harm source!
    boss:registerHarmSource("Explosion", 0.5)

    -- What colliders can be hit?
    boss:registerCollider(boss.collider, 1)

    boss:initHP()
    -- These 3 lines are a bit nonstandard. Usually you would define function boss:onTick() and work with the self-variable, but I re-route it into a different function so that all instances of the Waddle Dee boss can use the same function.
    boss.onTick = onBossTick
    boss.onDraw = onBossDraw
    boss.onHarm = onBossHarm
    table.insert(dees, boss)
    return boss
end

-- These are basically very slim NPCs. You can give them collision, states and whatnot.
function deathEffectProjectile:onTick(k,v)
    if v.lifetime == nil then
        v.lifetime = 300
        v.frame = v.frame or 0
        deathEffectExplosionProjectile:spawn{x = v.x + 0.5 * v.width, y = v.y + 0.5 * v.height}
    end

    if v.speedX > 0 then
        v.frame = 1
    else
        v.frame = 0
    end

    v.speedY = v.speedY + 0.2

    v.lifetime = v.lifetime - 1

    if v.lifetime <= 0 then
        v:kill()
    end
end

function deathEffectProjectile:onDraw(k,v)
    if v.frame == nil then return end
    Graphics.drawImageToSceneWP(self.sprite, v.x, v.y, 0, 46 * v.frame, 66, 46, self.z)
end

function deathEffectExplosionProjectile:onTick(k,v)
    if v.timer == nil then
        v.frame = v.frame or 0
        v.timer = 0
        v.collider = Colliders.Circle(v.x, v.y, 80)
        for k,n in ipairs(dees) do
            if n.hp > 0 then
                if Colliders.collide(v.collider, n.collider) then
                    n:damage("Explosion", true)
                end
            end
        end
        SFX.play("DemoResources/sfx_boom.wav")
    end

    v.timer = v.timer + 1

    v.frame = math.floor(v.timer / 2)

    if v.frame == 18 then
        v:kill()
    end
end

function deathEffectExplosionProjectile:onDraw(k,v)
    if v.frame == nil then return end
    Graphics.drawImageToSceneWP(self.sprite, v.x - 0.5 * v.width, v.y - 0.5 * v.height, 0, 160 * v.frame, 160, 160, self.z)
end

return w