How to use:
The included demo provides a simple example for the libraries' functions.
Adversary.lua is for boss management
Projectiles.lua is for making pure lua projectiles
They go very well together, so I combined them into this package.

If you wanna make your own boss using adversary, make sure to also copy the "adversary" folder.
It contains necessary sprites for the health bar.